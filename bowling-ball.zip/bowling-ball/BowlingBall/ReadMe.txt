﻿Game Class - The Game class is responsible to calculate the total for Ten - Pin Bowling 
GetScore() - This method is called from Game Class. It is used to calculate the score for valid sequence of rolls.
			  int[] arrRollSeq(Input) - The input to this method is valid sequence of rolls