﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Unity;

namespace BowlingBall
{
    /// <summary>
    /// This class is used to calculate the total for Ten - Pin Bowling
    /// </summary>
    public class Game
    {
        /// <summary>
        /// Logger
        /// </summary>
        private ILogger _logger;

        /// <summary>
        /// Constructor
        /// </summary>
        public Game()
        {
            UnityContainer unityContainer = new UnityContainer();
            unityContainer.RegisterType<ILogger, Logger>();
            _logger = unityContainer.Resolve<ILogger>();
        }

        /// <summary>
        /// This method is used to produce the total score of valid sequence of rolls for Ten - Pin Bowling.
        /// </summary>
        /// <param name="arrRollSeq"></param>
        /// <returns></returns>
        public int GetScore(int[] arrRollSeq)
        {
            //Counter to iterate through the sequence of rolls
            int arrCounter = 0;
            //Variable to hold the total score
            int totalScore = 0;
            try
            {
                while (true)
                {
                    //Check for strikes
                    if (arrRollSeq[arrCounter] == 10)
                    {
                        totalScore = totalScore + arrRollSeq[arrCounter] + arrRollSeq[arrCounter + 1] + arrRollSeq[arrCounter + 2];
                        arrCounter = arrCounter + 1;
                    }
                    //Check for spares
                    else if (arrRollSeq[arrCounter] + arrRollSeq[arrCounter + 1] == 10)
                    {
                        totalScore = totalScore + arrRollSeq[arrCounter] + arrRollSeq[arrCounter + 1] + arrRollSeq[arrCounter + 2];
                        arrCounter = arrCounter + 2;
                    }
                    else
                    {
                        totalScore = totalScore + arrRollSeq[arrCounter] + arrRollSeq[arrCounter + 1];
                        arrCounter = arrCounter + 2;
                    }

                    if (arrCounter >= arrRollSeq.Length - 2)
                    {
                        break;
                    }
                }
            }
            catch(Exception ex)
            {
                _logger.log("Error Occured : - " + ex.Message.ToString());
                return totalScore;
            }
           
            return totalScore;
        }
    }
}
