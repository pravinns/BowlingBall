﻿using System;
using System.IO;

namespace BowlingBall
{
    public class Logger : ILogger
    {
        private string currentDirectory { get; set; }
        private string fileName { get; set; }
        private string filePath { get; set; }

        public Logger()
        {
            this.currentDirectory = Directory.GetCurrentDirectory();
            this.fileName = "Log.txt";
            this.filePath = this.currentDirectory + "/" + this.fileName;
        }
        public void log(string message)
        {
            using (StreamWriter writer = File.AppendText(this.filePath))
            {
                writer.Write("\r\nLog Entry : ");
                writer.WriteLine("{0} {1}", DateTime.Now.ToLongTimeString(), DateTime.Now.ToLongDateString());
                writer.WriteLine(" :{0}", message);
                writer.WriteLine("-----------------------------------------------------------------------------");
            }
        }
    }
}
