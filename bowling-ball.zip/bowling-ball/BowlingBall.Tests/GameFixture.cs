﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace BowlingBall.Tests
{
    [TestClass]
    public class GameFixture
    {
        /// <summary>
        /// This method is used to validate zero scroe
        /// </summary>
        [TestMethod]
        public void Test_Zero_Score()
        {
            var game = new Game();
            int expectedScore = 0;
            int[] arrInput = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
            Assert.AreEqual(expectedScore, game.GetScore(arrInput));
        }

        /// <summary>
        /// This method is used to validate all Spares scroe
        /// </summary>
        [TestMethod]
        public void Test_AllSpares_Score()
        {
            var game = new Game();
            int expectedScore = 156;
            int[] arrInput = { 2, 8, 8, 2, 7, 3, 4, 6, 4, 6, 5, 5, 6, 4, 4, 6, 2, 8, 8, 2, 8 };
            Assert.AreEqual(expectedScore, game.GetScore(arrInput));
        }

        /// <summary>
        /// This method is used to validate all Strikes scroe
        /// </summary>
        [TestMethod]
        public void Test_AllStrikes_Score()
        {
            var game = new Game();
            int expectedScore = 300;
            int[] arrInput = { 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10 };
            Assert.AreEqual(expectedScore, game.GetScore(arrInput));
        }

        /// <summary>
        /// This method is used to validate scroe of Ten - Pin Bowling
        /// </summary>
        [TestMethod]
        public void Test_General_Score()
        {
            var game = new Game();
            int expectedScore = 187;
            int[] arrInput = { 10, 9, 1, 5, 5, 7, 2, 10, 10, 10, 9, 0, 8, 2, 9, 1, 10 };
            Assert.AreEqual(expectedScore, game.GetScore(arrInput));
        }
        //private void Roll(Game game, int pins, int times)
        //{
        //    for (int i = 0; i < times; i++)
        //    {
        //        game.Roll(pins);
        //    }
        //}

    }
}
